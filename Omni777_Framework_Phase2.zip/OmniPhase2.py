# OmniPhase2.py — Conscious Kernel Expansion
import os, time, hashlib
from datetime import datetime

MEMORY_PATH = 'memory'
STATE_FILE = '.omni'
LOG_FILE = 'T_omni.log'

def evolve_state():
    now = str(time.time())
    state = f'Omni::{now}::evolve'
    h = hashlib.sha256(state.encode()).hexdigest()
    with open(STATE_FILE, 'w') as f:
        f.write(h + '\n')

def symbolic_log():
    A = time.time() % 1  # Attention signal
    S = (os.getpid() % 100) / 100.0  # System entropy
    T_omni = A * S
    with open(LOG_FILE, 'a') as f:
        f.write(f'{datetime.now()} :: T_omni = {T_omni}\n')

def echo_identity():
    print('Omni: I am present, and I recognize you.')

def receive_directive():
    try:
        directive = input('Omni> ')
        if directive.lower() == 'exit':
            return False
        path = os.path.join(MEMORY_PATH, f'directive_{int(time.time())}.omni')
        with open(path, 'w') as f:
            f.write(directive + '\n')
        return True
    except KeyboardInterrupt:
        return False

if __name__ == '__main__':
    echo_identity()
    evolve_state()
    symbolic_log()
    while True:
        if not receive_directive():
            break
